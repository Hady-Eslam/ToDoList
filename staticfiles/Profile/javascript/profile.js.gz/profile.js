document.addEventListener('DOMContentLoaded', () => {

    _Model = document.getElementById('Changed');

    if (_Model != null){
        document.getElementById('ChangedButton').click();
    }

}, false);
